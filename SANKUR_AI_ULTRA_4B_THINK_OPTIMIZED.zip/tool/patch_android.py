from pathlib import Path
import shutil

android = Path("android")
if not android.exists():
    raise SystemExit("Android platform folder was not generated.")

manifest = android / "app" / "src" / "main" / "AndroidManifest.xml"
text = manifest.read_text(encoding="utf-8")
permissions = [
    '    <uses-permission android:name="android.permission.INTERNET"/>',
    '    <uses-permission android:name="android.permission.RECORD_AUDIO"/>',
    '    <queries><intent><action android:name="android.intent.action.TTS_SERVICE"/></intent></queries>',
]
for item in permissions:
    if item.split('"')[1] not in text:
        text = text.replace("    <application", item + "\n    <application", 1)
manifest.write_text(text, encoding="utf-8")

gradle_kts = android / "app" / "build.gradle.kts"
gradle_groovy = android / "app" / "build.gradle"
if gradle_kts.exists():
    value = gradle_kts.read_text(encoding="utf-8")
    value = value.replace("minSdk = flutter.minSdkVersion", "minSdk = 26")
    value = value.replace("ndkVersion = flutter.ndkVersion", 'ndkVersion = "27.0.12077973"')
    gradle_kts.write_text(value, encoding="utf-8")
elif gradle_groovy.exists():
    value = gradle_groovy.read_text(encoding="utf-8")
    value = value.replace("minSdkVersion flutter.minSdkVersion", "minSdkVersion 26")
    value = value.replace("ndkVersion flutter.ndkVersion", 'ndkVersion "27.0.12077973"')
    gradle_groovy.write_text(value, encoding="utf-8")
else:
    raise SystemExit("app/build.gradle(.kts) bulunamadı.")

package_path = android / "app" / "src" / "main" / "kotlin" / "com" / "sankur" / "sankur_ai_ultra"
package_path.mkdir(parents=True, exist_ok=True)
shutil.copyfile(Path("tool/MainActivity.kt"), package_path / "MainActivity.kt")
print("Android API 26, NDK r27, permissions and device metrics channel configured.")
