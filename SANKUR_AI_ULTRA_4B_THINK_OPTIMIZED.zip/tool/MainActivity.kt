package com.sankur.sankur_ai_ultra

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import android.os.StatFs
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "sankur/device"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getMetrics" -> {
                        try {
                            val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                            val memory = ActivityManager.MemoryInfo()
                            manager.getMemoryInfo(memory)
                            val stat = StatFs(filesDir.absolutePath)
                            result.success(
                                mapOf(
                                    "totalRamBytes" to memory.totalMem,
                                    "availableRamBytes" to memory.availMem,
                                    "freeStorageBytes" to stat.availableBytes
                                )
                            )
                        } catch (error: Exception) {
                            result.error("DEVICE_METRICS", error.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
