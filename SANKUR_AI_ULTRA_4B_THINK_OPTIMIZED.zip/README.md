# SANKUR AI ULTRA — Complete Android Local AI

## Bu sürümde gerçekten çalışan altyapı
- Android uygulamasının içinde llama.cpp tabanlı GGUF inference (Termux/harici sunucu gerekmez).
- Model Lab: uygulama içinden Hugging Face model indirme, indirme ilerlemesi/iptali, GGUF içe aktarma, model silme ve gerçek model değiştirme. İçe aktarılan özel GGUF dosyaları da listelenir ve yüklenebilir.
- Cihaz bilgisi: toplam RAM, kullanılabilir RAM, uygulama alanında boş depolama; GPU/Vulkan algılama ve katman tavsiyesi.
- Altı uzman agent ve her agent için ayrı SQLite sohbet hafızası.
- Güvenli araç yönlendiricisi: matematik hesaplayıcı, cihazın yerel saati, ajanın sohbet hafızasında arama ve ajana eklenen dokümanlarda arama.
- Türkçe sesli giriş (Android'in konuşma tanıma motoru üzerinden) ve Türkçe TTS yanıtı.
- TXT/MD/JSON/CSV/LOG/XML/YAML, Dart/Python/C++/Godot/JS/Java/Kotlin kaynak dosyaları, DOCX ve metin tabanlı PDF metin çıkarımı.
- OCR yapılmaz; taranmış/görüntü tabanlı PDF'lerde metin olmayabilir.

## Önerilen ücretsiz modeller
1. Qwen3 0.6B Q8 — yaklaşık 639 MB; düşük RAM'li telefonlarda ilk deneme.
2. Qwen3 1.7B Q4_K_M — yaklaşık 1.28 GB; daha iyi denge.
3. Qwen3 4B Q3_K_M — yaklaşık 2.08 GB; 4 GB sınıfı telefonlarda ilk denenmesi gereken 4B seçeneği, yine de yükleme garantisi yoktur.
4. Qwen3 4B Q4_K_M — yaklaşık 2.50 GB; daha yüksek quantization kalitesi, fakat 4 GB RAM cihazlarda bellek yetersizliği riski yüksektir.
5. Qwen3 4B Q2_K — yaklaşık 1.67 GB; Q3 yüklenemezse denenebilecek, kalite kaybı daha yüksek yedek.

Qwen3 model aileleri Apache-2.0 lisanslıdır. Model ağırlıkları bu kaynak ZIP'ine dahil edilmez; uygulamadaki Model Lab'dan ayrıca indirilir. Hugging Face indirmeleri için ilk kurulumda internet gerekir. Model indikten ve yüklendikten sonra metin sohbeti cihaz içinde çevrimdışı çalışır.

Model dosya boyutu RAM ihtiyacına eşit değildir. Model yükleme sırasında ek bellek, context ve Android süreçleri de RAM kullanır. Uygulama düşük boş RAM uyarısı verir ancak yükleme başarısını garanti edemez. 4 GB RAM sınıfında 4B için önce Q3_K_M kullan; yükleme başarısızsa Q2_K'yi dene. Q4_K_M daha fazla bellek ister. Uygulama boş RAM'e göre context'i 1024/2048/4096, CPU thread sayısını ve GPU katman kullanımını seçer. Düşük RAM'de Vulkan katmanlarını zorlamaz. Qwen3 düşünme uyumlu örnekleme ayarları temperature 0.6, top-p 0.95 ve top-k 20 olarak ayarlanmıştır. 1024 context profilinde çıktı bütçesi 384 token, 2048 ve üstünde 768 token ile sınırlandırılır; input bütçesi buna göre küçültülür. Her kullanıcı isteğinde Qwen3 `/think` modu tetiklenir. Düşünme metni kullanıcıya gösterilmez; yalnız final yanıt gösterilir. Sohbet geçmişi ve ekli dosya içeriği context bütçesine göre kısaltılır.

## APK oluşturma — Android telefon üzerinden
1. Bu ZIP'i çıkar.
2. GitHub'da yeni ve boş bir repository aç.
3. ZIP içeriğini repository'nin kök dizinine yükle (gizli `.github` klasörünü de dahil et).
4. `Actions` sekmesine gir ve `Build SANKUR AI Android APK` workflow'unu çalıştır.
5. İşlem başarılı olunca `SANKUR-AI-ULTRA-APK` artifact'ini indir; içindeki APK'yi Android'e kur.

Workflow, Android platform klasörünü kendisi üretir; API 26 ve NDK r27 ayarlarını yapar; Flutter/Gradle derlemesiyle arm64 release APK oluşturur.

## İlk kullanım
1. Uygulamayı aç → MODEL LAB.
2. İlk deneme için QWEN 3 • 0.6B Q8 → Ücretsiz indir.
3. İndirme bitince Bu modeli yükle.
4. Ana ekrana dön ve SANKUR ORACLE ile sohbet et.
5. Diğer agent'lar Agent Hub'dan seçilir. Her agent'ın geçmişi ayrıdır.
6. Dosya eklemek için ataç simgesini kullan; ardından dosya hakkında sorunu gönder.
7. Mikrofon simgesi sesli giriş, hoparlör simgesi otomatik sesli yanıtı açar/kapatır.

## Teknik notlar
- llama_flutter_android 0.2.6 yerel Android llama.cpp eklentisidir ve Android API 26+ ister. Native derleme NDK r27 kullanır.
- Uygulama model dosyalarını kendi özel uygulama dizininde saklar. Uygulamayı kaldırmak bu dosyaları da siler.
- Android konuşma tanıma servisi cihaz üreticisine/kurulu dil paketine bağlıdır; bazı cihazlarda çevrimdışı tanıma dil paketi yüklemek gerekir. TTS de Android'de kurulu ses motoruna bağlıdır.
- Araç çağrıları modelin JSON biçimindeki talimatı takip etmesine dayanır. Model aracı doğru biçimde istemezse normal metin yanıtı üretir; araç sistemi rastgele kod/shell çalıştırmaz.
- Sohbet geçmişi ve içe aktarılan metinler SQLite'ta cihazda saklanır. Ayarlar > Hafıza bölümünden sohbet geçmişi temizlenebilir; belgeler korunur.
- PDF metin çıkarımı Syncfusion Flutter PDF kullanır. Dağıtım/ticari kullanım öncesinde Syncfusion lisans şartlarını kontrol edin.
- Bu kaynak paketi hazırlanırken Flutter SDK/Android derleme ortamı bulunmadığından APK burada derlenip cihazda test edilmedi. GitHub Actions, kaynak kodu analiz ederek APK üretir; build sonucunu kontrol edin.

## Kullanılan açık kaynaklar
- llama_flutter_android: https://pub.dev/packages/llama_flutter_android
- Syncfusion Flutter PDF: https://pub.dev/packages/syncfusion_flutter_pdf
- Qwen3 0.6B GGUF: https://huggingface.co/Qwen/Qwen3-0.6B-GGUF
- Qwen3 1.7B GGUF: https://huggingface.co/ggml-org/Qwen3-1.7B-GGUF
- Qwen3 4B GGUF: https://huggingface.co/Qwen/Qwen3-4B-GGUF
