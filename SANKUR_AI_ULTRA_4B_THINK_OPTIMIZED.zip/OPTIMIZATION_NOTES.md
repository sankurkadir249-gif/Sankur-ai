# SANKUR AI ULTRA — 4B / 4 GB optimizasyon notları

## Bu güncelleme
- Qwen3-4B için Q3_K_M, Q4_K_M ve Q2_K GGUF seçenekleri eklendi.
- 4 GB sınıfı cihazlarda önce Q3_K_M denenir; Q3 yüklenmezse Q2_K yedek seçenektir. Q4_K_M daha fazla bellek ister.
- RAM durumuna göre 1024 / 2048 / 4096 context, CPU thread sayısı ve GPU katmanları seçilir.
- 4 GB RAM sınıfında varsayılan CPU yolu kullanılır; Vulkan katmanları zorlanmaz.
- Qwen3 `/think` modu her kullanıcı mesajında tetiklenir.
- Thinking sampling: temperature 0.6, top-p 0.95, top-k 20, min-p 0.0, repeat penalty 1.05.
- Düşünme aşaması token sınırında tamamlanmazsa ham düşünce kullanıcıya gösterilmez.
- Sohbet geçmişi, ekli dosya ve araç sonuçları context bütçesine göre kısaltılır.

## Gerçekçi donanım beklentisi
4 GB toplam RAM, 4B Q4 modelin kesin çalışacağı anlamına gelmez. Q3_K_M dosyası yaklaşık 2.08 GB, Q4_K_M yaklaşık 2.50 GB, Q2_K yaklaşık 1.67 GB boyutundadır. Model belleği, KV cache, Android ve diğer uygulamalar ek RAM kullanır. Model yükleme başarısı telefonun boş RAM'ine, Android sürümüne, sürücüye ve model runtime'ına bağlıdır. İlk olarak Q3_K_M denenmeli; yüklenmezse arka plan uygulamaları kapatılıp yeniden denenmeli, ardından Q2_K kullanılmalıdır.

## Doğrulama durumu
Bu kaynak paketi güncellendi; çalışma ortamında Flutter/Dart SDK bulunmadığı için APK derlemesi ve gerçek cihaz testi yapılmadı. Android release APK için GitHub Actions workflow'unun başarılı tamamlanması gerekir.
