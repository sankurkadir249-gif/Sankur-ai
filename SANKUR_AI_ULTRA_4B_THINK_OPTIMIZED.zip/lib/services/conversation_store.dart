import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class ChatRecord {
  const ChatRecord({
    required this.role,
    required this.content,
    required this.createdAt,
  });

  final String role;
  final String content;
  final int createdAt;

  factory ChatRecord.fromMap(Map<String, Object?> map) => ChatRecord(
        role: map['role'] as String,
        content: map['content'] as String,
        createdAt: map['created_at'] as int,
      );
}

class StoredDocument {
  const StoredDocument({
    required this.id,
    required this.name,
    required this.charCount,
  });

  final int id;
  final String name;
  final int charCount;
}

class ConversationStore {
  ConversationStore._();
  static final ConversationStore instance = ConversationStore._();

  Database? _db;

  Future<void> init() async {
    if (_db != null) return;
    final directory = await getApplicationDocumentsDirectory();
    _db = await openDatabase(
      p.join(directory.path, 'sankur_memory.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at INTEGER NOT NULL
          )
        ''');
        await db.execute('CREATE INDEX idx_messages_agent ON messages(agent_id, id)');
        await db.execute('''
          CREATE TABLE documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_id TEXT NOT NULL,
            name TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at INTEGER NOT NULL
          )
        ''');
        await db.execute('CREATE INDEX idx_documents_agent ON documents(agent_id, id)');
      },
    );
  }

  Database get db {
    final value = _db;
    if (value == null) throw StateError('Hafıza veritabanı başlatılmadı.');
    return value;
  }

  Future<void> addMessage(String agentId, String role, String content) async {
    await db.insert('messages', {
      'agent_id': agentId,
      'role': role,
      'content': content,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<ChatRecord>> getRecentMessages(
    String agentId, {
    int limit = 20,
  }) async {
    final rows = await db.query(
      'messages',
      where: 'agent_id = ?',
      whereArgs: [agentId],
      orderBy: 'id DESC',
      limit: limit,
    );
    return rows.reversed.map(ChatRecord.fromMap).toList();
  }

  Future<List<String>> searchMessages(String agentId, String query) async {
    final rows = await db.query(
      'messages',
      columns: ['role', 'content'],
      where: 'agent_id = ? AND content LIKE ?',
      whereArgs: [agentId, '%$query%'],
      orderBy: 'id DESC',
      limit: 5,
    );
    return rows
        .map((row) => '${row['role']}: ${row['content']}')
        .toList();
  }

  Future<void> clearAgentMessages(String agentId) async {
    await db.delete('messages', where: 'agent_id = ?', whereArgs: [agentId]);
  }

  Future<void> saveDocument(String agentId, String name, String content) async {
    final clipped = content.length > 180000
        ? content.substring(0, 180000)
        : content;
    await db.insert('documents', {
      'agent_id': agentId,
      'name': name,
      'content': clipped,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<StoredDocument>> getDocuments(String agentId) async {
    final rows = await db.query(
      'documents',
      columns: ['id', 'name', 'content'],
      where: 'agent_id = ?',
      whereArgs: [agentId],
      orderBy: 'id DESC',
    );
    return rows.map((row) => StoredDocument(
      id: row['id'] as int,
      name: row['name'] as String,
      charCount: (row['content'] as String).length,
    )).toList();
  }

  Future<List<String>> searchDocuments(String agentId, String query) async {
    final rows = await db.query(
      'documents',
      columns: ['name', 'content'],
      where: 'agent_id = ?',
      whereArgs: [agentId],
      orderBy: 'id DESC',
      limit: 20,
    );
    final needle = query.toLowerCase();
    final results = <String>[];
    for (final row in rows) {
      final content = row['content'] as String;
      final index = content.toLowerCase().indexOf(needle);
      if (index >= 0) {
        final start = (index - 140).clamp(0, content.length).toInt();
        final end = (index + 500).clamp(0, content.length).toInt();
        results.add('[${row['name']}]: ${content.substring(start, end)}');
      }
      if (results.length == 4) break;
    }
    return results;
  }
}
