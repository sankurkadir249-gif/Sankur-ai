import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:xml/xml.dart';

class ExtractedFile {
  const ExtractedFile({required this.name, required this.text});
  final String name;
  final String text;
}

class FileAnalysisService {
  static const _extensions = [
    'txt', 'md', 'json', 'csv', 'log', 'xml', 'yaml', 'yml',
    'dart', 'py', 'cpp', 'h', 'hpp', 'gd', 'cs', 'js', 'ts',
    'java', 'kt', 'html', 'css', 'sql', 'pdf', 'docx',
  ];

  Future<ExtractedFile?> pickAndExtract() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: _extensions,
      allowMultiple: false,
      withData: false,
    );
    if (result == null || result.files.isEmpty) return null;
    final picked = result.files.single;
    final path = picked.path;
    if (path == null) throw Exception('Dosyanın yerel konumu alınamadı.');
    final file = File(path);
    final length = await file.length();
    if (length > 60 * 1024 * 1024) {
      throw Exception('Dosya 60 MB sınırını aşıyor. Daha küçük bir dosya seç.');
    }

    final extension = picked.extension?.toLowerCase() ?? '';
    final bytes = await file.readAsBytes();
    String text;

    if (extension == 'pdf') {
      final document = PdfDocument(inputBytes: bytes);
      try {
        text = PdfTextExtractor(document).extractText();
      } finally {
        document.dispose();
      }
      if (text.trim().isEmpty) {
        throw Exception('PDF içinde seçilebilir metin bulunamadı. Taranmış PDF/OCR henüz desteklenmiyor.');
      }
    } else if (extension == 'docx') {
      text = _extractDocx(bytes);
    } else {
      text = utf8.decode(bytes, allowMalformed: true);
    }

    text = text.trim();
    if (text.isEmpty) throw Exception('Dosyadan okunabilir metin çıkarılamadı.');
    if (text.length > 180000) {
      text = '${text.substring(0, 180000)}\n\n[Dosya güvenli bağlam sınırı nedeniyle kısaltıldı.]';
    }
    return ExtractedFile(name: picked.name, text: text);
  }

  String _extractDocx(List<int> bytes) {
    final archive = ZipDecoder().decodeBytes(bytes);
    final documentFile = archive.findFile('word/document.xml');
    if (documentFile == null) throw Exception('DOCX içinde word/document.xml bulunamadı.');
    final xmlBytes = documentFile.content as List<int>;
    final xml = XmlDocument.parse(utf8.decode(xmlBytes, allowMalformed: true));
    return xml
        .findAllElements('w:t')
        .map((element) => element.innerText)
        .join(' ')
        .replaceAll(RegExp(r'\s+'), ' ');
  }
}
