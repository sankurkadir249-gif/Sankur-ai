import 'dart:io';

import 'package:llama_flutter_android/llama_flutter_android.dart';

import 'device_metrics.dart';

class GpuProfile {
  const GpuProfile({
    required this.name,
    required this.vulkanSupported,
    required this.recommendedGpuLayers,
    required this.freeRamBytes,
  });

  final String name;
  final bool vulkanSupported;
  final int recommendedGpuLayers;
  final int freeRamBytes;
}

class LocalInferenceService {
  LlamaController? _controller;
  bool isLoaded = false;
  String? loadedPath;
  GpuProfile? gpuProfile;
  bool _generating = false;
  int _contextSize = 1024;
  int _maxOutputTokens = 512;
  int _promptCharBudget = 3072;

  int get contextSize => _contextSize;
  int get maxOutputTokens => _maxOutputTokens;
  int get promptCharBudget => _promptCharBudget;

  Future<GpuProfile?> inspectDevice() async {
    final probe = LlamaController();
    try {
      final dynamic info = await probe.detectGpu();
      final metrics = await DeviceMetricsService.read();
      final profile = GpuProfile(
        name: (info.gpuName as String?) ?? 'Android GPU',
        vulkanSupported: (info.vulkanSupported as bool?) ?? false,
        recommendedGpuLayers: (info.recommendedGpuLayers as int?) ?? 0,
        freeRamBytes: metrics?.availableRamBytes ??
            (info.freeRamBytes as int?) ?? 0,
      );
      gpuProfile = profile;
      return profile;
    } catch (_) {
      return null;
    } finally {
      await probe.dispose();
    }
  }

  Future<void> loadModel(String path) async {
    final file = File(path);
    if (!await file.exists()) throw Exception('GGUF dosyası bulunamadı.');
    if (_generating) throw Exception('Yanıt üretimi sürerken model değiştirilemez.');

    await unloadModel();
    final controller = LlamaController();
    try {
      final dynamic gpu = await controller.detectGpu();
      final metrics = await DeviceMetricsService.read();
      final totalRam = metrics?.totalRamBytes ?? 0;
      final pluginFreeRam = (gpu.freeRamBytes as int?) ?? 0;
      final freeRam = metrics?.availableRamBytes ?? pluginFreeRam;
      final fourGbClass = totalRam > 0 && totalRam <= 5 * 1024 * 1024 * 1024;

      // 4 GB sınıfı cihazlarda kısa context ve az iş parçacığı OOM riskini azaltır.
      final int context = fourGbClass
          ? (freeRam >= 2400 * 1024 * 1024 ? 2048 : 1024)
          : (freeRam >= 3500 * 1024 * 1024
              ? 4096
              : (freeRam >= 1900 * 1024 * 1024 ? 2048 : 1024));
      final int threads = fourGbClass
          ? (freeRam >= 2200 * 1024 * 1024 ? 3 : 2)
          : (freeRam >= 3500 * 1024 * 1024 ? 4 : 3);

      // Paylaşımlı mobil bellekte Vulkan katmanlarını zorlamak bazen toplam RAM
      // tüketimini artırır. Düşük RAM sınıfında CPU yolu daha güvenli varsayılandır.
      final bool vulkan = (gpu.vulkanSupported as bool?) ?? false;
      final int recommendedLayers = (gpu.recommendedGpuLayers as int?) ?? 0;
      final int gpuLayers = !fourGbClass && vulkan &&
              freeRam >= 3500 * 1024 * 1024
          ? recommendedLayers
          : 0;

      await controller.loadModel(
        modelPath: path,
        threads: threads,
        contextSize: context,
        gpuLayers: gpuLayers,
      );

      _controller = controller;
      isLoaded = true;
      loadedPath = path;
      _contextSize = context;
      _maxOutputTokens = context >= 2048 ? 768 : 384;
      _promptCharBudget = ((context - _maxOutputTokens - 96) * 3.0).floor();
      gpuProfile = GpuProfile(
        name: (gpu.gpuName as String?) ?? 'Android GPU',
        vulkanSupported: vulkan,
        recommendedGpuLayers: gpuLayers,
        freeRamBytes: freeRam,
      );
    } catch (error) {
      await controller.dispose();
      rethrow;
    }
  }

  Future<String> generateChat(
    List<ChatMessage> messages, {
    int? maxTokens,
    double temperature = 0.6,
  }) async {
    final controller = _controller;
    if (!isLoaded || controller == null) {
      throw StateError('Önce bir yerel GGUF modeli yüklemelisin.');
    }
    if (_generating) throw StateError('Model zaten yanıt üretiyor.');
    _generating = true;
    try {
      final output = StringBuffer();
      final tokenLimit = (maxTokens ?? _maxOutputTokens)
          .clamp(128, _contextSize - 128)
          .toInt();
      await for (final token in controller.generateChat(
        messages: messages,
        maxTokens: tokenLimit,
        temperature: temperature,
        topP: 0.95,
        topK: 20,
        minP: 0.0,
        repeatPenalty: 1.05,
      )) {
        output.write(token);
      }
      final text = _removePrivateThinking(output.toString());
      if (text.isEmpty) throw Exception('Model boş yanıt üretti.');
      return text;
    } finally {
      _generating = false;
    }
  }

  String _removePrivateThinking(String value) {
    var text = value.trim();
    final lower = text.toLowerCase();
    final closingTag = lower.lastIndexOf('</think>');

    // Qwen3 GGUF şablonları <think> açılışını generation prefix içine
    // koyabilir; bu durumda token akışında yalnız </think> görünür.
    if (closingTag >= 0) {
      text = text.substring(closingTag + '</think>'.length);
    } else if (lower.contains('<think>')) {
      text = text.replaceFirst(
        RegExp(r'<think>[\s\S]*$', caseSensitive: false),
        '',
      );
    } else {
      // /think isteğinde kapanış işareti yoksa düşünme tamamlanmamış
      // olabilir. İç düşünce metnini yanlışlıkla kullanıcıya göstermeyiz.
      return 'Düşünme aşaması tamamlanamadı. Daha kısa bir istekle tekrar dene.';
    }

    return text.replaceAll('<|im_end|>', '').trim();
  }

  Future<void> stop() async {
    if (_controller != null && _generating) {
      await _controller!.stop();
    }
  }

  Future<void> unloadModel() async {
    final old = _controller;
    _controller = null;
    isLoaded = false;
    loadedPath = null;
    if (old != null) await old.dispose();
  }

  Future<void> dispose() async {
    await unloadModel();
  }
}
