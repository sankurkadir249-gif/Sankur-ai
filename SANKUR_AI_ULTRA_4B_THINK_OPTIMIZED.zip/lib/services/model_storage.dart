import 'dart:io';

import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/model_catalog.dart';

class ModelStorage {
  final Dio _dio = Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 30),
    receiveTimeout: const Duration(minutes: 45),
    followRedirects: true,
    headers: const {'User-Agent': 'SANKUR-AI-Android'},
  ));

  Directory? _directory;
  SharedPreferences? _preferences;

  Future<void> init() async {
    final support = await getApplicationSupportDirectory();
    _directory = Directory('${support.path}/models');
    await _directory!.create(recursive: true);
    _preferences = await SharedPreferences.getInstance();
  }

  Future<SharedPreferences> get preferences async {
    _preferences ??= await SharedPreferences.getInstance();
    return _preferences!;
  }

  Directory get directory {
    final value = _directory;
    if (value == null) throw StateError('ModelStorage başlatılmadı.');
    return value;
  }

  File fileFor(AiModel model) => File('${directory.path}/${model.fileName}');

  Future<String?> pathIfInstalled(AiModel model) async {
    final file = fileFor(model);
    if (!await file.exists()) return null;
    final size = await file.length();
    if (size < model.minimumFileBytes) return null;
    return file.path;
  }

  Future<bool> isInstalled(AiModel model) async =>
      (await pathIfInstalled(model)) != null;

  Future<List<FileSystemEntity>> listInstalledFiles() async {
    if (!await directory.exists()) return [];
    return directory
        .list()
        .where((entity) => entity is File && entity.path.toLowerCase().endsWith('.gguf'))
        .toList();
  }

  Future<String> downloadModel(
    AiModel model, {
    required void Function(int received, int total) onProgress,
    required CancelToken cancelToken,
  }) async {
    final target = fileFor(model);
    if (await target.exists() && await target.length() >= model.minimumFileBytes) {
      return target.path;
    }
    final partial = File('${target.path}.part');
    if (await partial.exists()) await partial.delete();

    try {
      await _dio.download(
        model.downloadUrl,
        partial.path,
        cancelToken: cancelToken,
        deleteOnError: true,
        onReceiveProgress: onProgress,
        options: Options(
          responseType: ResponseType.stream,
          validateStatus: (status) => status != null && status >= 200 && status < 300,
        ),
      );
      if (!await partial.exists()) {
        throw Exception('İndirme dosyası oluşturulamadı.');
      }
      final length = await partial.length();
      if (length < model.minimumFileBytes) {
        await partial.delete();
        throw Exception('İndirilen dosya beklenenden küçük. Bağlantı kesilmiş olabilir.');
      }
      if (await target.exists()) await target.delete();
      return await partial.rename(target.path);
    } catch (_) {
      if (await partial.exists()) await partial.delete();
      rethrow;
    }
  }

  Future<String?> importLocalModel() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['gguf'],
      allowMultiple: false,
      withData: false,
    );
    if (result == null || result.files.isEmpty) return null;
    final sourcePath = result.files.single.path;
    if (sourcePath == null) {
      throw Exception('Seçilen dosyanın yerel yolu okunamadı.');
    }
    final source = File(sourcePath);
    final length = await source.length();
    if (length < 100 * 1024 * 1024) {
      throw Exception('Dosya GGUF modeline göre çok küçük görünüyor.');
    }
    final safeName = result.files.single.name.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    final target = File('${directory.path}/$safeName');
    await source.copy(target.path);
    return target.path;
  }

  Future<void> deleteModel(AiModel model) async {
    final file = fileFor(model);
    if (await file.exists()) await file.delete();
  }

  Future<void> deleteFile(String path) async {
    final file = File(path);
    if (await file.exists()) await file.delete();
  }

  Future<void> cancelPartialDownloads() async {
    if (!await directory.exists()) return;
    await for (final item in directory.list()) {
      if (item is File && item.path.endsWith('.part')) {
        await item.delete();
      }
    }
  }
}
