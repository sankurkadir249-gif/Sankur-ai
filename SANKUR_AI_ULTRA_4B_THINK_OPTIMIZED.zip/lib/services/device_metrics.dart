import 'package:flutter/services.dart';

class DeviceMetrics {
  const DeviceMetrics({
    required this.totalRamBytes,
    required this.availableRamBytes,
    required this.freeStorageBytes,
  });

  final int totalRamBytes;
  final int availableRamBytes;
  final int freeStorageBytes;

  String get totalRamLabel => _gb(totalRamBytes);
  String get availableRamLabel => _gb(availableRamBytes);
  String get freeStorageLabel => _gb(freeStorageBytes);

  static String _gb(int value) => '${(value / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
}

class DeviceMetricsService {
  static const _channel = MethodChannel('sankur/device');

  static Future<DeviceMetrics?> read() async {
    try {
      final result = await _channel.invokeMapMethod<String, int>('getMetrics');
      if (result == null) return null;
      return DeviceMetrics(
        totalRamBytes: result['totalRamBytes'] ?? 0,
        availableRamBytes: result['availableRamBytes'] ?? 0,
        freeStorageBytes: result['freeStorageBytes'] ?? 0,
      );
    } on MissingPluginException {
      return null;
    } on PlatformException {
      return null;
    }
  }
}
