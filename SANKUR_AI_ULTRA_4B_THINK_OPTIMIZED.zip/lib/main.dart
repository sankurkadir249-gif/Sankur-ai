import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import 'data/agent_catalog.dart';
import 'services/agent_tools.dart';
import 'services/conversation_store.dart';
import 'services/device_metrics.dart';
import 'services/file_analysis_service.dart';
import 'services/inference_service.dart';
import 'services/model_storage.dart';
import 'screens/model_lab_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ConversationStore.instance.init();
  final storage = ModelStorage();
  await storage.init();
  runApp(SankurApp(storage: storage));
}

class SankurApp extends StatelessWidget {
  const SankurApp({super.key, required this.storage});
  final ModelStorage storage;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SANKUR AI ULTRA',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07111F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00C8FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: ChatScreen(storage: storage),
    );
  }
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.storage});
  final ModelStorage storage;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  final _scroll = ScrollController();
  final _inference = LocalInferenceService();
  final _store = ConversationStore.instance;
  final _speech = stt.SpeechToText();
  final _tts = FlutterTts();
  final _fileService = FileAnalysisService();
  late final AgentToolsService _agentTools;

  AiAgent _agent = aiAgents.first;
  String? _activeModelName;
  String? _pendingFileName;
  String? _pendingFileText;
  List<ChatRecord> _messages = [];
  DeviceMetrics? _metrics;
  bool _busy = false;
  bool _voiceReply = false;
  bool _speechReady = false;
  String _status = 'Model seçmek için MODEL LAB ekranını aç.';

  @override
  void initState() {
    super.initState();
    _agentTools = AgentToolsService(_inference, _store);
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      final prefs = await widget.storage.preferences;
      final savedAgent = prefs.getString('active_agent');
      if (savedAgent != null) {
        _agent = aiAgents.firstWhere(
          (a) => a.id == savedAgent,
          orElse: () => aiAgents.first,
        );
      }
      _metrics = await DeviceMetricsService.read();
      await _loadAgentHistory();
      final savedPath = prefs.getString('active_model_path');
      final savedName = prefs.getString('active_model_name');
      if (savedPath != null && await File(savedPath).exists()) {
        try {
          await _inference.loadModel(savedPath);
          _activeModelName = savedName ?? savedPath.split('/').last;
          _status = 'Yerel AI hazır • $_activeModelName';
        } catch (e) {
          _status = 'Model otomatik yüklenemedi: $e';
        }
      }
    } catch (e) {
      _status = 'Başlatma uyarısı: $e';
    }
    if (mounted) setState(() {});
  }

  Future<void> _loadAgentHistory() async {
    final history = await _store.getRecentMessages(_agent.id, limit: 40);
    if (mounted) setState(() => _messages = history);
  }

  Future<void> _selectAgent(AiAgent agent) async {
    if (_busy) return;
    setState(() => _agent = agent);
    final prefs = await widget.storage.preferences;
    await prefs.setString('active_agent', agent.id);
    await _loadAgentHistory();
    _toast('${agent.name} aktif. Bu ajanın hafızası ayrıdır.');
  }

  Future<void> _openModelLab() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ModelLabScreen(
          storage: widget.storage,
          inference: _inference,
          currentModelName: _activeModelName,
          metrics: _metrics,
          onModelLoaded: (model, modelPath) async {
            final prefs = await widget.storage.preferences;
            await prefs.setString('active_model', model.id);
            await prefs.setString('active_model_path', modelPath);
            await prefs.setString('active_model_name', model.name);
            if (!mounted) return;
            setState(() {
              _activeModelName = model.name;
              _status = 'Yerel AI hazır • ${model.shortName}';
            });
          },
        ),
      ),
    );
    _metrics = await DeviceMetricsService.read();
    if (mounted) setState(() {});
  }

  Future<void> _attachFile() async {
    if (_busy) return;
    try {
      final picked = await _fileService.pickAndExtract();
      if (picked == null) return;
      await _store.saveDocument(_agent.id, picked.name, picked.text);
      setState(() {
        _pendingFileName = picked.name;
        _pendingFileText = picked.text;
      });
      _toast('${picked.name} analiz için eklendi. Sorunu yazıp gönder.');
    } catch (e) {
      _toast('Dosya okunamadı: $e');
    }
  }

  Future<void> _send() async {
    final question = _text.text.trim();
    if (question.isEmpty || _busy) return;
    if (!_inference.isLoaded) {
      _toast('Önce MODEL LAB bölümünden bir GGUF modeli indirip yükle.');
      return;
    }
    _text.clear();
    final fileText = _pendingFileText;
    final fileName = _pendingFileName;
    setState(() {
      _busy = true;
      _messages.add(ChatRecord(
        role: 'user',
        content: fileName == null ? question : '[$fileName eklendi]\n$question',
        createdAt: DateTime.now().millisecondsSinceEpoch,
      ));
    });
    try {
      await _store.addMessage(_agent.id, 'user',
          fileName == null ? question : '[$fileName eklendi]\n$question');
      final history = await _store.getRecentMessages(_agent.id, limit: 18);
      final answer = await _agentTools.answer(
        agent: _agent,
        history: history,
        attachedFileName: fileName,
        attachedFileText: fileText,
      );
      await _store.addMessage(_agent.id, 'assistant', answer);
      if (!mounted) return;
      setState(() {
        _messages.add(ChatRecord(
          role: 'assistant',
          content: answer,
          createdAt: DateTime.now().millisecondsSinceEpoch,
        ));
        _pendingFileName = null;
        _pendingFileText = null;
      });
      _scrollToBottom();
      if (_voiceReply) {
        await _speak(answer);
      }
    } catch (e) {
      final error = 'Yanıt üretilemedi: $e';
      if (mounted) {
        setState(() => _messages.add(ChatRecord(
          role: 'assistant',
          content: error,
          createdAt: DateTime.now().millisecondsSinceEpoch,
        )));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _startVoiceInput() async {
    if (_busy) return;
    try {
      _speechReady = await _speech.initialize(
        onError: (error) => _toast('Ses tanıma hatası: ${error.errorMsg}'),
        onStatus: (status) {
          if (status == 'done' || status == 'notListening') {
            if (mounted) setState(() {});
          }
        },
      );
      if (!_speechReady) {
        _toast('Bu cihazda kullanılabilir ses tanıma hizmeti bulunamadı.');
        return;
      }
      await _speech.listen(
        localeId: 'tr_TR',
        onResult: (result) {
          if (mounted) setState(() => _text.text = result.recognizedWords);
        },
      );
      if (mounted) setState(() {});
    } catch (e) {
      _toast('Mikrofon başlatılamadı: $e');
    }
  }

  Future<void> _stopVoiceInput() async {
    await _speech.stop();
    if (mounted) setState(() {});
  }

  Future<void> _speak(String value) async {
    try {
      await _tts.setLanguage('tr-TR');
      await _tts.setSpeechRate(0.48);
      await _tts.speak(value);
    } catch (e) {
      _toast('Sesli yanıt kullanılamıyor: $e');
    }
  }

  Future<void> _showAgents() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF0B1726),
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('AGENT HUB',
                style: TextStyle(
                    fontSize: 21,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF00C8FF))),
            const SizedBox(height: 8),
            ...aiAgents.map((agent) => ListTile(
                  leading: Text(agent.emoji,
                      style: const TextStyle(fontSize: 25)),
                  title: Text(agent.name,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(agent.tagline),
                  trailing: _agent.id == agent.id
                      ? const Icon(Icons.check_circle, color: Colors.green)
                      : const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.pop(sheetContext);
                    _selectAgent(agent);
                  },
                )),
          ]),
        ),
      ),
    );
  }

  Future<void> _showMemory() async {
    final docs = await _store.getDocuments(_agent.id);
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF0B1726),
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('AGENT MEMORY',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFF00C8FF))),
            Text('${_agent.name} için saklanan dosyalar ve sohbet hafızası',
                style: const TextStyle(color: Colors.white60)),
            const SizedBox(height: 10),
            if (docs.isEmpty) const Text('Henüz bu ajana dosya eklenmedi.'),
            ...docs.take(8).map((doc) => ListTile(
                  dense: true,
                  leading: const Icon(Icons.description_outlined),
                  title: Text(doc.name),
                  subtitle: Text('${doc.charCount} karakter'),
                )),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: () async {
                  await _store.clearAgentMessages(_agent.id);
                  if (sheetContext.mounted) Navigator.pop(sheetContext);
                  await _loadAgentHistory();
                  _toast('Bu ajanın sohbet hafızası temizlendi. Dosyalar korunur.');
                },
                icon: const Icon(Icons.delete_outline),
                label: const Text('Sohbet geçmişini temizle'),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _text.dispose();
    _scroll.dispose();
    _speech.cancel();
    _tts.stop();
    _inference.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
          Text('SANKUR AI',
              style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          Text('ULTRA • ON-DEVICE INTELLIGENCE',
              style: TextStyle(
                  fontSize: 9, color: Color(0xFF00C8FF), letterSpacing: 1.3)),
        ]),
        actions: [
          IconButton(
              tooltip: 'Model Lab',
              onPressed: _openModelLab,
              icon: const Icon(Icons.memory)),
          IconButton(
              tooltip: 'Agent Hub',
              onPressed: _showAgents,
              icon: const Icon(Icons.smart_toy_outlined)),
          IconButton(
              tooltip: 'Dosya ekle',
              onPressed: _attachFile,
              icon: const Icon(Icons.attach_file)),
          IconButton(
              tooltip: 'Hafıza',
              onPressed: _showMemory,
              icon: const Icon(Icons.psychology_alt_outlined)),
        ],
      ),
      body: Column(children: [
        Container(
          width: double.infinity,
          margin: const EdgeInsets.fromLTRB(12, 4, 12, 8),
          padding: const EdgeInsets.all(11),
          decoration: BoxDecoration(
            color: const Color(0xFF102237),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: const Color(0xFF17405B)),
          ),
          child: Row(children: [
            Icon(_inference.isLoaded ? Icons.bolt : Icons.info_outline,
                color: _inference.isLoaded
                    ? const Color(0xFF57E3B0)
                    : const Color(0xFFFFC36B),
                size: 18),
            const SizedBox(width: 8),
            Expanded(
                child: Text(
              _activeModelName == null ? _status : '$_status  •  ${_agent.name}',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, color: Colors.white70),
            )),
            if (_voiceReply)
              IconButton(
                tooltip: 'Sesli yanıt açık',
                onPressed: () => setState(() => _voiceReply = false),
                icon: const Icon(Icons.volume_up, color: Color(0xFF00C8FF)),
              )
            else
              IconButton(
                tooltip: 'Sesli yanıtı aç',
                onPressed: () => setState(() => _voiceReply = true),
                icon: const Icon(Icons.volume_off, color: Colors.white38),
              ),
          ]),
        ),
        Expanded(
          child: _messages.isEmpty
              ? _welcome()
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
                  itemCount: _messages.length,
                  itemBuilder: (context, index) {
                    final message = _messages[index];
                    final isUser = message.role == 'user';
                    return Align(
                      alignment: isUser
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: 350),
                        margin: const EdgeInsets.only(bottom: 11),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: isUser
                              ? const Color(0xFF123B58)
                              : const Color(0xFF111F30),
                          borderRadius: BorderRadius.circular(17),
                          border: Border.all(
                              color: isUser
                                  ? const Color(0xFF17618C)
                                  : const Color(0xFF18354B)),
                        ),
                        child: SelectableText(
                          message.content,
                          style: const TextStyle(fontSize: 14, height: 1.45),
                        ),
                      ),
                    );
                  },
                ),
        ),
        if (_pendingFileName != null)
          Container(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 6),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
                color: const Color(0xFF11283A),
                borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              const Icon(Icons.description, size: 16, color: Color(0xFF00C8FF)),
              const SizedBox(width: 7),
              Expanded(
                  child: Text('Eklendi: $_pendingFileName',
                      maxLines: 1, overflow: TextOverflow.ellipsis)),
              IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: () => setState(() {
                        _pendingFileName = null;
                        _pendingFileText = null;
                      }),
                  icon: const Icon(Icons.close, size: 17)),
            ]),
          ),
        if (_busy)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              SizedBox(
                  width: 15,
                  height: 15,
                  child: CircularProgressIndicator(strokeWidth: 2)),
              SizedBox(width: 9),
              Text('SANKUR düşünüyor...',
                  style: TextStyle(color: Colors.white60, fontSize: 12)),
            ]),
          ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
            child: Row(children: [
              IconButton(
                tooltip: _speech.isListening ? 'Dinlemeyi durdur' : 'Sesle yaz',
                onPressed:
                    _speech.isListening ? _stopVoiceInput : _startVoiceInput,
                icon: Icon(
                  _speech.isListening ? Icons.mic : Icons.mic_none,
                  color: _speech.isListening
                      ? Colors.redAccent
                      : const Color(0xFF00C8FF),
                ),
              ),
              Expanded(
                child: TextField(
                  controller: _text,
                  minLines: 1,
                  maxLines: 5,
                  onSubmitted: (_) => _send(),
                  decoration: InputDecoration(
                    hintText: 'SANKUR AI’a mesaj yaz...',
                    filled: true,
                    fillColor: const Color(0xFF101D2C),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(23),
                        borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 13),
                  ),
                ),
              ),
              const SizedBox(width: 7),
              IconButton.filled(
                onPressed: _busy ? null : _send,
                icon: const Icon(Icons.arrow_upward),
                style: IconButton.styleFrom(
                    backgroundColor: const Color(0xFF00A9D8),
                    foregroundColor: Colors.white),
              ),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _welcome() => Center(
        child: Padding(
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.auto_awesome,
                size: 52, color: Color(0xFF00C8FF)),
            const SizedBox(height: 14),
            const Text('SANKUR AI ULTRA',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 21)),
            const SizedBox(height: 7),
            Text(
              _inference.isLoaded
                  ? 'Model hazır. Bir şey sor veya uzman ajanını seç.'
                  : 'Önce MODEL LAB bölümünden bir GGUF modelini indir ve yükle.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white60, height: 1.4),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _openModelLab,
              icon: const Icon(Icons.memory),
              label: const Text('MODEL LAB’I AÇ'),
            ),
          ]),
        ),
      );
}
