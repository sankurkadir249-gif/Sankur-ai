import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../data/model_catalog.dart';
import '../services/device_metrics.dart';
import '../services/inference_service.dart';
import '../services/model_storage.dart';

class ModelLabScreen extends StatefulWidget {
  const ModelLabScreen({
    super.key,
    required this.storage,
    required this.inference,
    required this.currentModelName,
    required this.metrics,
    required this.onModelLoaded,
  });

  final ModelStorage storage;
  final LocalInferenceService inference;
  final String? currentModelName;
  final DeviceMetrics? metrics;
  final Future<void> Function(AiModel model, String modelPath) onModelLoaded;

  @override
  State<ModelLabScreen> createState() => _ModelLabScreenState();
}

class _ModelLabScreenState extends State<ModelLabScreen> {
  final Map<String, double> _progress = {};
  final Map<String, String> _status = {};
  final Map<String, CancelToken> _tokens = {};
  final Set<String> _loading = {};
  final Set<String> _installed = {};
  List<File> _customFiles = [];
  String? _activePath;
  String? _activeName;
  bool _importing = false;
  GpuProfile? _gpu;
  DeviceMetrics? _deviceMetrics;

  @override
  void initState() {
    super.initState();
    _activePath = widget.inference.loadedPath;
    _activeName = widget.currentModelName;
    _deviceMetrics = widget.metrics;
    _refresh();
  }

  Future<void> _refresh() async {
    final found = <String>{};
    for (final model in aiModels) {
      if (await widget.storage.isInstalled(model)) found.add(model.id);
    }
    final allFiles = await widget.storage.listInstalledFiles();
    final freshMetrics = await DeviceMetricsService.read();
    final knownNames = aiModels.map((model) => model.fileName).toSet();
    final customs = allFiles
        .whereType<File>()
        .where((file) => !knownNames.contains(file.uri.pathSegments.last))
        .toList();
    final gpu = await widget.inference.inspectDevice();
    if (!mounted) return;
    setState(() {
      _installed
        ..clear()
        ..addAll(found);
      _customFiles = customs;
      _gpu = gpu;
      _deviceMetrics = freshMetrics ?? _deviceMetrics;
    });
  }

  Future<void> _download(AiModel model) async {
    final freeStorage = _deviceMetrics?.freeStorageBytes ?? 0;
    if (freeStorage > 0 &&
        freeStorage < model.estimatedDownloadBytes + 200 * 1024 * 1024) {
      _toast('Yetersiz boş depolama. Bu model için en az ${(model.estimatedDownloadBytes / 1024 / 1024 / 1024).toStringAsFixed(1)} GB ve ek geçici alan gerekiyor.');
      return;
    }
    final token = CancelToken();
    _tokens[model.id] = token;
    setState(() {
      _status[model.id] = 'İndirme hazırlanıyor...';
      _progress[model.id] = 0;
    });
    try {
      await widget.storage.downloadModel(
        model,
        cancelToken: token,
        onProgress: (received, total) {
          if (!mounted) return;
          setState(() {
            _progress[model.id] = total > 0 ? received / total : 0;
            _status[model.id] = total > 0
                ? '${(received / 1024 / 1024).toStringAsFixed(0)} / ${(total / 1024 / 1024).toStringAsFixed(0)} MB'
                : 'İndiriliyor...';
          });
        },
      );
      if (!mounted) return;
      setState(() {
        _installed.add(model.id);
        _status[model.id] = 'İndirme tamamlandı';
        _progress[model.id] = 1;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _status[model.id] = token.isCancelled ? 'İndirme iptal edildi' : 'İndirme hatası: $error';
      });
    } finally {
      _tokens.remove(model.id);
    }
  }

  Future<void> _load(AiModel model) async {
    final path = await widget.storage.pathIfInstalled(model);
    if (path == null) {
      _toast('Önce bu modeli indir.');
      return;
    }
    final availableRam = _deviceMetrics?.availableRamBytes ?? _gpu?.freeRamBytes ?? 0;
    if (availableRam > 0 && availableRam < model.minimumFreeRamBytes) {
      final accepted = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('RAM düşük olabilir'),
          content: Text(
            'Bu model için ${model.ramLabel} öneriliyor. Şu an yaklaşık ${(availableRam / 1024 / 1024 / 1024).toStringAsFixed(1)} GB boş RAM görünüyor. Yine de yüklemeyi denemek ister misin? Android uygulamayı kapatabilir.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Yine de dene')),
          ],
        ),
      );
      if (accepted != true) return;
    }

    setState(() => _loading.add(model.id));
    try {
      await widget.inference.loadModel(path);
      await widget.onModelLoaded(model, path);
      if (!mounted) return;
      setState(() {
        _activePath = path;
        _activeName = model.name;
      });
      _toast('${model.shortName} telefonda yüklendi.');
    } catch (error) {
      _toast('Model yüklenemedi: $error');
    } finally {
      if (mounted) setState(() => _loading.remove(model.id));
    }
  }

  Future<void> _importModel() async {
    setState(() => _importing = true);
    try {
      final path = await widget.storage.importLocalModel();
      if (path != null) {
        _activePath = path;
        _toast('GGUF dosyası uygulama model klasörüne kopyalandı.');
      }
    } catch (error) {
      _toast('Model içe aktarılamadı: $error');
    } finally {
      if (mounted) {
        setState(() => _importing = false);
        await _refresh();
      }
    }
  }

  Future<void> _delete(AiModel model) async {
    if (_activePath == (await widget.storage.pathIfInstalled(model))) {
      await widget.inference.unloadModel();
      _activePath = null;
      _activeName = null;
    }
    await widget.storage.deleteModel(model);
    if (!mounted) return;
    setState(() {
      _installed.remove(model.id);
      _status.remove(model.id);
      _progress.remove(model.id);
    });
  }

  void _toast(String value) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  String _formatBytes(int value) {
    if (value <= 0) return 'Bilinmiyor';
    return '${(value / 1024 / 1024 / 1024).toStringAsFixed(1)} GB';
  }

  @override
  void dispose() {
    for (final token in _tokens.values) {
      token.cancel('Ekran kapatıldı');
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final totalRam = widget.metrics?.totalRamBytes ?? 0;
    final availableRam = _deviceMetrics?.availableRamBytes ?? _gpu?.freeRamBytes ?? 0;
    final storage = widget.metrics?.freeStorageBytes ?? 0;
    return Scaffold(
      appBar: AppBar(title: const Text('MODEL LAB', style: TextStyle(fontWeight: FontWeight.w900))),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          _deviceCard(totalRam, availableRam, storage),
          const SizedBox(height: 14),
          Row(children: [
            const Expanded(child: Text('MODEL KÜTÜPHANESİ', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF00C8FF), letterSpacing: 1))),
            TextButton.icon(onPressed: _importing ? null : _importModel, icon: const Icon(Icons.file_open), label: const Text('GGUF içe aktar')),
          ]),
          ...aiModels.map(_modelCard),
          if (_customFiles.isNotEmpty) ...[
            const SizedBox(height: 10),
            const Text('İÇE AKTARILAN MODELLER', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF00C8FF), letterSpacing: 1)),
            ..._customFiles.map(_customModelCard),
          ],
          const SizedBox(height: 12),
          const Text(
            'Model değiştirme: Yeni model yüklendiğinde önce eski model bellekten çıkarılır. İndirme işlemi internet gerektirir; model yüklendikten sonra sohbet tamamen cihazda çalışır.',
            style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
          ),
        ],
      ),
    );
  }

  Future<void> _loadCustom(File file) async {
    final size = await file.length();
    final name = file.uri.pathSegments.last;
    final model = AiModel(
      id: 'custom_${name.hashCode}',
      name: 'CUSTOM • $name',
      shortName: name,
      fileName: name,
      downloadUrl: '',
      sizeLabel: '${(size / 1024 / 1024 / 1024).toStringAsFixed(2)} GB',
      ramLabel: 'Dosyaya göre otomatik tahmin edilemez',
      minimumFreeRamBytes: 0,
      minimumFileBytes: 100 * 1024 * 1024,
      estimatedDownloadBytes: size,
      description: 'Kullanıcı tarafından içe aktarılan GGUF modeli.',
      license: 'Model lisansını kontrol et',
    );
    setState(() => _loading.add(model.id));
    try {
      await widget.inference.loadModel(file.path);
      await widget.onModelLoaded(model, file.path);
      if (!mounted) return;
      setState(() {
        _activePath = file.path;
        _activeName = model.name;
      });
      _toast('$name yüklendi.');
    } catch (error) {
      _toast('Özel model yüklenemedi: $error');
    } finally {
      if (mounted) setState(() => _loading.remove(model.id));
    }
  }

  Future<void> _deleteCustom(File file) async {
    if (_activePath == file.path) {
      await widget.inference.unloadModel();
      _activePath = null;
      _activeName = null;
    }
    await widget.storage.deleteFile(file.path);
    if (mounted) {
      setState(() => _customFiles.removeWhere((item) => item.path == file.path));
    }
  }

  Widget _customModelCard(File file) {
    final name = file.uri.pathSegments.last;
    final id = 'custom_${name.hashCode}';
    final active = _activePath == file.path;
    final loading = _loading.contains(id);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF101D2C),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: active ? const Color(0xFF00C8FF) : const Color(0xFF1B3347)),
      ),
      child: Row(children: [
        const Icon(Icons.folder_special, color: Color(0xFF00C8FF)),
        const SizedBox(width: 9),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
          FutureBuilder<int>(
            future: file.length(),
            builder: (_, snapshot) => Text(
              snapshot.hasData ? '${(snapshot.data! / 1024 / 1024 / 1024).toStringAsFixed(2)} GB • Yerel dosya' : 'Boyut okunuyor...',
              style: const TextStyle(color: Colors.white54, fontSize: 11),
            ),
          ),
        ])),
        IconButton(
          onPressed: loading || active ? null : () => _loadCustom(file),
          icon: loading
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
              : Icon(active ? Icons.check_circle : Icons.play_arrow, color: active ? Colors.green : null),
        ),
        IconButton(
          onPressed: () => _deleteCustom(file),
          icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
        ),
      ]),
    );
  }

  Widget _deviceCard(int total, int free, int storage) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF10324A), Color(0xFF101D30)]),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF1B536F)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('CİHAZ DURUMU', style: TextStyle(color: Color(0xFF00C8FF), fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        _metricRow('Toplam RAM', _formatBytes(total)),
        _metricRow('Kullanılabilir RAM', _formatBytes(free)),
        _metricRow('Boş depolama', _formatBytes(storage)),
        _metricRow('GPU', _gpu?.name ?? 'Donanım bilgisi alınamadı'),
        _metricRow('Vulkan', _gpu == null ? 'Bilinmiyor' : (_gpu!.vulkanSupported ? 'Destekleniyor' : 'Kullanılmıyor')),
        const SizedBox(height: 7),
        const Text('RAM tahminleri yaklaşık değerlerdir. Gerçek yükleme başarısı cihaz, Android ve arka plan uygulamalarına bağlıdır.',
            style: TextStyle(fontSize: 11, color: Colors.white54)),
      ]),
    );
  }

  Widget _metricRow(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(children: [
      Expanded(child: Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12))),
      Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
    ]),
  );

  Widget _modelCard(AiModel model) {
    final installed = _installed.contains(model.id);
    final downloading = _tokens.containsKey(model.id);
    final loading = _loading.contains(model.id);
    final progress = _progress[model.id] ?? 0;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF101D2C),
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: _activeName == model.name ? const Color(0xFF00C8FF) : const Color(0xFF1B3347),
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.memory, color: Color(0xFF00C8FF)),
          const SizedBox(width: 9),
          Expanded(child: Text(model.name, style: const TextStyle(fontWeight: FontWeight.w900))),
          if (_activeName == model.name)
            const Icon(Icons.check_circle, color: Color(0xFF57E3B0), size: 19)
          else
            Text(model.license, style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ]),
        const SizedBox(height: 7),
        Text('${model.sizeLabel} • ${model.ramLabel}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
        const SizedBox(height: 5),
        Text(model.description, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        if (_status[model.id] != null) ...[
          const SizedBox(height: 8),
          LinearProgressIndicator(value: downloading ? (progress > 0 ? progress : null) : (progress == 1 ? 1 : null)),
          const SizedBox(height: 4),
          Text(_status[model.id]!, style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ],
        const SizedBox(height: 9),
        Row(children: [
          if (downloading)
            OutlinedButton.icon(
              onPressed: () => _tokens[model.id]?.cancel('Kullanıcı iptal etti'),
              icon: const Icon(Icons.close),
              label: const Text('İptal'),
            )
          else if (!installed)
            FilledButton.icon(
              onPressed: () => _download(model),
              icon: const Icon(Icons.download),
              label: const Text('Ücretsiz indir'),
            )
          else
            FilledButton.icon(
              onPressed: loading || _activeName == model.name ? null : () => _load(model),
              icon: loading
                  ? const SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.play_arrow),
              label: Text(_activeName == model.name ? 'Aktif model' : 'Bu modeli yükle'),
            ),
          const Spacer(),
          if (installed)
            IconButton(
              tooltip: 'Modeli sil',
              onPressed: () => _delete(model),
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
            ),
        ]),
      ]),
    );
  }
}
