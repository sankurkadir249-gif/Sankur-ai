class AiModel {
  const AiModel({
    required this.id,
    required this.name,
    required this.shortName,
    required this.fileName,
    required this.downloadUrl,
    required this.sizeLabel,
    required this.ramLabel,
    required this.minimumFreeRamBytes,
    required this.minimumFileBytes,
    required this.estimatedDownloadBytes,
    required this.description,
    required this.license,
  });

  final String id;
  final String name;
  final String shortName;
  final String fileName;
  final String downloadUrl;
  final String sizeLabel;
  final String ramLabel;
  final int minimumFreeRamBytes;
  final int minimumFileBytes;
  final int estimatedDownloadBytes;
  final String description;
  final String license;
}

const aiModels = <AiModel>[
  AiModel(
    id: 'qwen3_06_q8',
    name: 'QWEN 3 • 0.6B Q8',
    shortName: 'Qwen3 0.6B',
    fileName: 'Qwen3-0.6B-Q8_0.gguf',
    downloadUrl: 'https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q8_0.gguf',
    sizeLabel: '639 MB',
    ramLabel: 'Yaklaşık 2 GB+ boş RAM',
    minimumFreeRamBytes: 1500 * 1024 * 1024,
    minimumFileBytes: 400 * 1024 * 1024,
    estimatedDownloadBytes: 639 * 1000 * 1000,
    description: 'En hafif seçenek. İlk deneme ve düşük RAM için önerilir.',
    license: 'Apache-2.0',
  ),
  AiModel(
    id: 'qwen3_17_q4',
    name: 'QWEN 3 • 1.7B Q4_K_M',
    shortName: 'Qwen3 1.7B',
    fileName: 'Qwen3-1.7B-Q4_K_M.gguf',
    downloadUrl: 'https://huggingface.co/ggml-org/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf',
    sizeLabel: '1.28 GB',
    ramLabel: 'Yaklaşık 3.5 GB+ boş RAM',
    minimumFreeRamBytes: 2800 * 1024 * 1024,
    minimumFileBytes: 850 * 1024 * 1024,
    estimatedDownloadBytes: 1280 * 1000 * 1000,
    description: 'Hız ve cevap kalitesi arasında daha iyi denge. Orta seviye telefonlar için.',
    license: 'Apache-2.0',
  ),
  AiModel(
    id: 'qwen3_4_q3',
    name: 'QWEN 3 • 4B Q3_K_M',
    shortName: 'Qwen3 4B Q3_K_M',
    fileName: 'Qwen3-4B-Q3_K_M.gguf',
    downloadUrl: 'https://huggingface.co/tensorblock/Qwen_Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q3_K_M.gguf',
    sizeLabel: 'Yaklaşık 2.08 GB',
    ramLabel: '4 GB telefonlarda denenebilecek seçenek; garanti değil',
    minimumFreeRamBytes: 1500 * 1024 * 1024,
    minimumFileBytes: 1700 * 1024 * 1024,
    estimatedDownloadBytes: 2076 * 1000 * 1000,
    description: '4B parametreli modeli daha küçük dosya boyutuyla sunar; Q4 sürümüne göre daha az bellek ister, ancak quantization nedeniyle kalite kaybı olabilir. 4 GB RAM için önce bunu dene.',
    license: 'Apache-2.0',
  ),
  AiModel(
    id: 'qwen3_4_q4',
    name: 'QWEN 3 • 4B Q4_K_M',
    shortName: 'Qwen3 4B Q4_K_M',
    fileName: 'Qwen3-4B-Q4_K_M.gguf',
    downloadUrl: 'https://huggingface.co/Qwen/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf',
    sizeLabel: 'Yaklaşık 2.50 GB',
    ramLabel: 'Daha yüksek boş RAM gerekir; 4 GB cihazda zorlanabilir',
    minimumFreeRamBytes: 2500 * 1024 * 1024,
    minimumFileBytes: 2100 * 1024 * 1024,
    estimatedDownloadBytes: 2497 * 1000 * 1000,
    description: '4B seçenekleri arasında daha iyi quantization kalitesi; yalnızca cihaz yeterli belleğe sahipse kullan.',
    license: 'Apache-2.0',
  ),
  AiModel(
    id: 'qwen3_4_q2',
    name: 'QWEN 3 • 4B Q2_K',
    shortName: 'Qwen3 4B Q2_K',
    fileName: 'Qwen3-4B-Q2_K.gguf',
    downloadUrl: 'https://huggingface.co/tensorblock/Qwen_Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q2_K.gguf',
    sizeLabel: 'Yaklaşık 1.67 GB',
    ramLabel: 'En düşük bellekli 4B alternatif; kalite kaybı var',
    minimumFreeRamBytes: 1100 * 1024 * 1024,
    minimumFileBytes: 1300 * 1024 * 1024,
    estimatedDownloadBytes: 1669 * 1000 * 1000,
    description: 'Q3 sürümü yüklenemezse denenecek bellek dostu yedek. Daha agresif quantization nedeniyle cevap kalitesi düşebilir.',
    license: 'Apache-2.0',
  ),
];

AiModel modelById(String id) =>
    aiModels.firstWhere((model) => model.id == id, orElse: () => aiModels.first);

